import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
// import{ TotalIncidentsTrendComponent } from "../../app/total-incidents-trend/total-incidents-trend.component"
import { partition } from "rxjs";


export class LineChart {

    static calculateAvg(data, label1, label2) {
        // console.log("checking callback for " + label1, label2);

        // console.log(data[0][label]);

        let sum = 0;

        console.log("Running average function");

        for (var i = 0; i < data.length; i++) {
            sum += parseInt(data[i][label1], 10) + parseInt(data[i][label2], 10); //don't forget to add the base
            // console.log(data[i][label]);
        }

        console.log("sum is " + sum);

        let avg = 0;
        avg = sum / data.length;

        console.log("avg is " + avg);
        console.log("CHECKING AVERAG CALLBACK :" + avg);
        console.log(data);

        if(avg === parseInt(avg, 10))
            // TotalIncidentsTrendComponent.calculateAvg(avg);
            return avg;

        return avg;
    }

    //static generateChart(chartdiv) {
    static generateChart(totalIncidentsTrend_data) {
        /* Chart code */
        // Themes begin
        am4core.useTheme(am4themes_animated);
        am4core.addLicense("CH213722778");
        // Themes end


        //
        let chartIds = [];
        // Create chart instance
        let chart = am4core.create("total_incidents_trend", am4charts.XYChart);

        // Add data
        chart.data = [{
            "date": "2020-01-01",
            "priority_1": "5",
            "priority_2": "20"
        }, {
            "date": "2020-02-02",
            "priority_1": "20",
            "priority_2": "75"
        }, {
            "date": "2020-03-03",
            "priority_1": "5",
            "priority_2": "25"
        },
        {
            "date": "2020-04-03",
            "priority_1": "20",
            "priority_2": "15"
        },
        {
            "date": "2020-05-03",
            "priority_1": "5",
            "priority_2": "30"
        },
        {
            "date": "2020-06-03",
            "priority_1": "5",
            "priority_2": "30"
        },
        {
            "date": "2020-07-01",
            "priority_1": "5",
            "priority_2": "20"
        }, {
            "date": "2020-08-02",
            "priority_1": "20",
            "priority_2": "75"
        }, {
            "date": "2020-09-03",
            "priority_1": "5",
            "priority_2": "25"
        },
        {
            "date": "2020-10-03",
            "priority_1": "20",
            "priority_2": "15"
        },
        {
            "date": "2020-11-03",
            "priority_1": "5",
            "priority_2": "30"
        },
        {
            "date": "2021-2-03",
            "priority_1": "5",
            "priority_2": "30"
        }
        ];


        chart.data = totalIncidentsTrend_data;
        this.calculateAvg(chart.data, "priority1", "priority2");

        



        // Create axes
        let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        dateAxis.renderer.grid.template.location = 0;
        dateAxis.renderer.minGridDistance = 50;
        dateAxis.renderer.grid.template.disabled = true;

        dateAxis.dateFormats.setKey("month", "MMM yy");
        dateAxis.periodChangeDateFormats.setKey("month", "MMM yy");
        // dateAxis.dateFormats.setKey("year", "yy");

        dateAxis.startLocation = 0.8;
        dateAxis.endLocation = 0.5;

        let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        // valueAxis.logarithmic = true;
        valueAxis.renderer.minGridDistance = 30;
        valueAxis.renderer.grid.template.disabled = true;

        // Create series 1
        let series = chart.series.push(new am4charts.LineSeries());
        series.name = "Priority 1";
        series.dataFields.valueY = "priority1";
        // series.dataFields.valueY = "kmart";
        series.dataFields.dateX = "month";
        series.tensionX = .8;
        series.tensionY = 1;

        // //log on
        // valueAxis.logarithmic = true;
        // series.tensionX = .8;
        // series.tensionY = .6;

        series.strokeWidth = 1;
        series.fillOpacity = 0.1;
        series.fill = am4core.color("#FB7C1A");
        series.stroke = am4core.color("#FB7C1A");

        // // bullets indicating data on x axis
        // let bullet = series.bullets.push(new am4charts.CircleBullet());
        // bullet.circle.fill = am4core.color("#fff");
        // bullet.circle.strokeWidth = 3;

        //create dummyData for series 1 to set
        // stroke color for legend marker
        series.dummyData = {
            colorStroke: "#FB7C1A",
            colorFlag: true
        };


        // Create series 2
        let series2 = chart.series.push(new am4charts.LineSeries());
        series2.name = "Priority 2";
        series2.dataFields.valueY = "priority2";
        series2.dataFields.dateX = "month";
        series2.tensionX = 0.8;
        series2.strokeWidth = 1;
        series2.fillOpacity = 0.1;
        series2.fill = am4core.color("#027DBA");
        series2.stroke = am4core.color("#027DBA");

        // // bullets indicating data on x axis
        // let bullet2 = series2.bullets.push(new am4charts.CircleBullet());
        // bullet2.circle.fill = am4core.color("#fff");
        // bullet2.circle.strokeWidth = 3;

        //create dummyData for series 2 to set
        // stroke color for legend marker
        series2.dummyData = {
            colorStroke: "#027DBA",
            colorFlag: true
        };


        //Create Legend
        let legend = chart.legend = new am4charts.Legend();
        // legend.position = "right";
        legend.valign = "top";
        legend.maxWidth = 300;
        legend.maxHeight = 20;
        //

        //legend markers
        // chart.legend = new am4charts.Legend();
        legend.useDefaultMarker = true;
        let marker = legend.markers.template.children.getIndex(0);
        // legend.markers.template.children.
        marker.width = 15;
        marker.height = 15;
        marker.cornerRadius(12, 12, 12, 12);
        marker.strokeWidth = 4;
        // marker.marginTop = 100;
        // marker.stroke = "#FB7C1A";
        // marker.fill = "none";
        marker.strokeOpacity = 1;
        marker.fillOpacity = 0;
        // marker.stroke = am4core.color("#ccc");


        //use adapter to set stroke color of each legend individually

        marker.adapter.add("stroke", function (stroke, target) {
            // console.log("target is active:" + target.isActive);
            if (target.isActive) {
                console.log("Adapter called");
                if (target.dataItem && target.dataItem.dataContext && target.dataItem.dataContext.dummyData) {
                    // console.log("flag " + target.dataItem.dataContext.dummyData.colorFlag)
                    // if (target.dataItem.dataContext.dummyData.colorFlag) {
                        console.log("Color stroke Returned");
                        target.dataItem.dataContext.dummyData.colorFlag = false;
                        return target.dataItem.dataContext.dummyData.colorStroke;
                    // } else return stroke;
                }
                else {
                    console.log("Stroke Returned");
                    return stroke;
                }
            }
        });

        /* Create a separate container to put legend in */
        let legendContainer = am4core.create("totalInicident_legenddiv", am4core.Container);
        // legendContainer.layout = "horizontal";
        legendContainer.width = am4core.percent(100);
        legendContainer.height = am4core.percent(100);
        // // legendContainer.padding = (0,0,0,0);
        // legendContainer.background.fill = am4core.color("#53CCD9");
        legend.parent = legendContainer;


        // // Add cursor
        // chart.cursor = new am4charts.XYCursor();
        // chart.cursor.fullWidthLineX = true;
        // chart.cursor.xAxis = dateAxis;
        // chart.cursor.lineX.strokeWidth = 0;
        // // chart.cursor.lineX.fill = am4core.color("#000");
        // chart.cursor.lineX.fill = am4core.color("#fb8d38");
        // chart.cursor.lineX.fillOpacity = 0.1;



        // Add scrollbar
        // chart.scrollbarX = new am4core.Scrollbar();

        // Add a guide (AVERAGE LINE)
        let range = valueAxis.axisRanges.create();
        //range.value = 30.4;
        range.value = this.calculateAvg(chart.data, "priority1", "priority2");
        range.grid.stroke = am4core.color("#396478");
        // range.grid.stroke = am4core.color("#fb8d38");
        range.grid.strokeWidth = 1;
        range.grid.strokeOpacity = 1;
        range.grid.strokeDasharray = "3,3";
        range.label.inside = true;
        // range.label.text = "Average";
        range.label.fill = range.grid.stroke;
        range.label.verticalCenter = "bottom";

        chartIds.push(chart.baseId);
        chartIds.push(legendContainer.baseId);
        return chartIds;
    }

}

