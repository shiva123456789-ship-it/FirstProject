import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DaysSinceMiReportedComponent } from './days-since-mi-reported.component';

describe('DaysSinceMiReportedComponent', () => {
  let component: DaysSinceMiReportedComponent;
  let fixture: ComponentFixture<DaysSinceMiReportedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DaysSinceMiReportedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DaysSinceMiReportedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
