import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncidentsByGroupComponent } from './incidents-by-group.component';

describe('IncidentsByGroupComponent', () => {
  let component: IncidentsByGroupComponent;
  let fixture: ComponentFixture<IncidentsByGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncidentsByGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncidentsByGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
