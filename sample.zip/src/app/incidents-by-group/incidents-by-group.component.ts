import { Component, OnInit } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';

import { BarChart } from "../../assets/ts/barChart"
import {AmchartLicenseCheck} from '../../assets/ts/amchart-license-check';

import {NGXLogger} from 'ngx-logger';
import {DigitalDashboardDataService} from '../digital-dashboard-data.service';
import {disposeAmchartById_2} from '../../assets/ts/amchart_maintenance_2';

interface Incident_By_Group{
  assignmentGroup : string;
  assignmentGroupCount : number;
}

interface Incident_By_Group_AllIntervals {
  IBG_CurrentMonth : Incident_By_Group[];
  IBG_Last90Days : Incident_By_Group[];
  
}

@Component({
  selector: 'app-incidents-by-group',
  templateUrl: './incidents-by-group.component.html',
  styleUrls: ['./incidents-by-group.component.css']
})
export class IncidentsByGroupComponent implements OnInit {

  chartTitle:string="Major Incidents By Group";
  chart_ALC : AmchartLicenseCheck;
  barChart: BarChart = new BarChart();
  durationInterval : string[] = ["current month","last 3 month"];
  selectedInterval:string = this.durationInterval[0];
  IBG_CurrentMonth : Incident_By_Group[];
  IBG_Last90Days : Incident_By_Group[];
  IBG_CurrentMonth_isSet : boolean;
  IBG_Last90Days_isSet : boolean;
  IBG_allInterval_data : Incident_By_Group_AllIntervals = {IBG_CurrentMonth : [],IBG_Last90Days : []};
  chartId_IBG_CurrentMonth : any;
  chartId_IBG_Last90Days : any;

  constructor(private logger: NGXLogger, 
    private dboard_dataService: DigitalDashboardDataService) { }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void{
    // request to get update data on updatedData_event
    this.dboard_dataService.get_updatedData_event.subscribe(() => {
      this.logger.debug("subscribed - get_updatedData_event");

      /*
      // (alternative) Single function for IBG_API_response
      this.dboard_dataService.get_IBG_API_response().subscribe((incidentByGroup_allIntervals) => {

        console.log("incidentByGroup_allIntervals: "+ incidentByGroup_allIntervals);
        
        this.IBG_allInterval_data.IBG_CurrentMonth = incidentByGroup_allIntervals.IBG_CurrentMonth;
        this.IBG_allInterval_data.IBG_Last90Days = incidentByGroup_allIntervals.IBG_Last90Days;

        if(this.selectedInterval = this.durationInterval[0]){
          this.barChart.generateChart(this.IBG_allInterval_data.IBG_CurrentMonth[0].assignmentGroup);
          //console.log("assignmentGroupCount: "+ this.IBG_allInterval_data.IBG_CurrentMonth.assignmentGroupCount);

        }else{
          this.barChart.generateChart(this.IBG_allInterval_data.IBG_Last90Days);
          //console.log("assignmentGroupCount: "+ assignmentGroupCount);

        }
          
        
      });
      */
    this.IBG_CurrentMonth = [];
    this.IBG_Last90Days = [];
    this.IBG_CurrentMonth_isSet = false;
    this.IBG_Last90Days_isSet = false;
    this.dboard_dataService.get_IBG_API_CurrentMonth_response().subscribe((incidentByGroup_data) => {
      this.IBG_CurrentMonth = incidentByGroup_data;
      this.IBG_CurrentMonth_isSet = true;
      this.disposeCharts();
      this.chartId_IBG_CurrentMonth = this.barChart.generateChart(this.IBG_CurrentMonth);
    });
    this.dboard_dataService.get_IBG_API_Last90Days_response().subscribe((incidentByGroup_data) => {
      this.IBG_Last90Days = incidentByGroup_data;
      this.IBG_Last90Days_isSet = true;
    });


    });

            // Toggle Region/Global
            setInterval(()=>{ 
              if(this.selectedInterval == this.durationInterval[0]){
                this.selectedInterval = this.durationInterval[1];
                this.intervalChanged();
              }else{
                this.selectedInterval = this.durationInterval[0];
                this.intervalChanged();   
              } 
            },30000);
    }

    intervalChanged(){
      if((this.selectedInterval == this.durationInterval[0]) && (this.IBG_CurrentMonth_isSet == true)){
        this.disposeCharts();
        this.chartId_IBG_CurrentMonth = this.barChart.generateChart(this.IBG_CurrentMonth);  
      }else if(this.IBG_Last90Days_isSet == true){
        this.disposeCharts();
         this.chartId_IBG_Last90Days = this.barChart.generateChart(this.IBG_Last90Days);
  
      }
    }

    disposeCharts(){
      disposeAmchartById_2(this.chartId_IBG_CurrentMonth);
      disposeAmchartById_2(this.chartId_IBG_Last90Days);
    }




}
