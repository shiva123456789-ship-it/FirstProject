import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OngoingIncidentDetailsComponent } from './ongoing-incident-details.component';

describe('OngoingIncidentDetailsComponent', () => {
  let component: OngoingIncidentDetailsComponent;
  let fixture: ComponentFixture<OngoingIncidentDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OngoingIncidentDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OngoingIncidentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
