import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MajorIncidentsThisMonthComponent } from './major-incidents-this-month.component';

describe('MajorIncidentsThisMonthComponent', () => {
  let component: MajorIncidentsThisMonthComponent;
  let fixture: ComponentFixture<MajorIncidentsThisMonthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MajorIncidentsThisMonthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MajorIncidentsThisMonthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
