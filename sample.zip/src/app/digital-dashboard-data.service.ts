import { Injectable } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { HttpClient, HttpHeaders } from '@angular/common/http';


interface Inc_Count {
  name: string;
  priority:string;
  count: number;
}

interface Inc_Details {
  incidentNumber : string;
  priority : string;
  state : string;
  regionsImpacted:string; 
  shortDescription: string;
}

interface Last_MI_Details {
   priority : string;
   days_count : number;
   value: string;
 }

 interface Total_Incidents_Trend {
  month : string;
  priority1 : number;
  priority2 : number;

}
interface Incident_By_Group{
  assignmentGroup : string;
  assignmentGroupCount : number;
}

interface Incident_By_Group_AllIntervals {
  IBG_CurrentMonth : Incident_By_Group[];
  IBG_Last90Days : Incident_By_Group[];
  
}
interface Incident_Outages {
  incidentNumber : string;
  priority : string;
  regionsImpacted:string;
  impactedServices:string;
  
}

@Injectable({
  providedIn: 'root'
})
export class DigitalDashboardDataService {
  
  //
  majorIncidentsThisMonth:Inc_Count[]=[];
  ongoingIncidents:Inc_Details[]=[];
  days_since_last_MI_reported: Last_MI_Details[] =[];


  //API settings
  
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      observe: 'response'
      // 'Authorization': 'Basic ' + btoa('username:password')
    })
  };

  //API URL's
  baseURL:string;
  DSLR_API="";
  MITM_API="";
  TIT_API="";
  OngoingIncidents_API="";
  IBG_CurrentMonth_API="";
  IBG_Last90Days_API="";
  LastTenOutages_API:string="";

  //to be removed with the use of get_updatedData_event
  public mi_thisMonth_UpdatedEvent = new Subject();
  public ongoingIncidents_UpdatedEvent = new Subject();

  //
  public get_updatedData_event = new Subject();
  public TIT_API_error_event = new Subject();
  public OngoingIncidents_API_error_event = new Subject();



  constructor(private logger: NGXLogger,private http: HttpClient) { 
        // Temp initial values
        this.baseURL = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/"
        this.majorIncidentsThisMonth=[];
        this.ongoingIncidents=[];
  }
  updateDataCall(){
    this.logger.debug("At - updateDataCall"); 
    this.get_updatedData_event.next();
  }
  /* Deprecated code to be removed
  call_digitalDashboard_APIs(){
    this.logger.debug("At DigitalDashboardDataService - call_digitalDashboard_APIs");

    // Temp initial values
    this.majorIncidentsThisMonth=[];
    this.ongoingIncidents=[];

    //Call Major Incidents This Month Api 
        // assign values from Api  
        
        this.majorIncidentsThisMonth.push({"name":'p1',"priority":"","count":Math.floor(Math.random() * (15 - 0 + 1)) + 0});
        this.majorIncidentsThisMonth.push({"name":'p2',"priority":"","count":Math.floor(Math.random() * (15 - 0 + 1)) + 0});
        this.mi_thisMonth_UpdatedEvent.next();

    //Call Major Incidents This Month Api 
        // assign values from Api
        var dummyStatus = ["New","In Progress","On Hold","Resolved","Canceled"];
        var dummyRegion = ["APAC","NA","SA","EMEA","Global"];
        var no_mockIncidentsReq=6;
        for (var _i = 0; _i < no_mockIncidentsReq ; _i++) {
          if((Math.floor(Math.random() * (no_mockIncidentsReq - 0 + 1)) + 0)%2==0){
            this.ongoingIncidents.push({"incident_number":'incident_'+_i,
            "priority":'p1',
            "state":dummyStatus[Math.floor(Math.random() * (4 - 0 + 1)) + 0],
            "region":dummyRegion[Math.floor(Math.random() * (4 - 0 + 1)) + 0],
            "description":"dummy_desc_"+_i});

          }
          else{
            this.ongoingIncidents.push({"incident_number":'incident_'+_i,
            "priority":'p2',
            "state":dummyStatus[Math.floor(Math.random() * (4 - 0 + 1)) + 0],
            "region":dummyRegion[Math.floor(Math.random() * (4 - 0 + 1)) + 0],
            "description":"dummy_desc_"+_i});

          }
          
        }            
        this.ongoingIncidents_UpdatedEvent.next();

    //Call Days since incident last reported API
    this.get_DSLMI_API_response();

  }
  */

  get_MITM_API_response():Observable<Inc_Count[]>{
    this.MITM_API="http://maznaddbd01/MIAPI/api/MajorIncidentAPI/MIThisMonth";
    this.logger.debug("At - get_MITM_API_response"); 
    
    return this.http.get<Inc_Count[]>(this.MITM_API , this.httpOptions)
    .pipe(
      catchError(this.handle_API_Error<Inc_Count[]>('get_MITM_API_response', []))
      );

  }


  get_DSLMI_API_response(): Observable<Last_MI_Details[]> { // 
    this.DSLR_API = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/MIDaysinceLastReported"

    return this.http.get<Last_MI_Details[]>(this.DSLR_API , this.httpOptions)
    .pipe(
      catchError(this.handle_API_Error<Last_MI_Details[]>('get_DSLMI_API_response', []))
    );

  }
  get_MIcount_API_response(){

  }
  get_TIT_API_response():Observable<Total_Incidents_Trend[]>{
    this.TIT_API = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/TotalIncidentsTrend"

    return this.http.get<Total_Incidents_Trend[]>(this.TIT_API , this.httpOptions)
    .pipe(
      catchError(this.handle_API_Error<Total_Incidents_Trend[]>('get_TIT_API_response', []))
    );

  }
  get_OngoingIncidents_API_response():Observable<Inc_Details[]>{
    this.OngoingIncidents_API = "";
    
    // this.ongoingIncidents = [{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST","regionsImpacted":"North America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST","regionsImpacted":"North America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST","regionsImpacted":"North America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"North America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"North America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"North America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"North America"}]
    // this.ongoingIncidents = [{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"South America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"South America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"South America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"South America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"South America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"South America"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"South America"}]
    // this.ongoingIncidents = [{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"EMEA"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"EMEA"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"EMEA"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"EMEA"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"EMEA"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"EMEA"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"EMEA"}];
    // this.ongoingIncidents = [{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"APAC"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"APAC"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"APAC"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"APAC"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"APAC"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"APAC"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"APAC"}];
    // this.ongoingIncidents = [{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"global"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"global"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"global"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"global"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"global"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"global"}];
    // this.ongoingIncidents = [{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"},{"incidentNumber":"TEST1","priority":"1 - Critical","state":"New","shortDescription":"TEST","regionsImpacted":"GLOBAL"}];
    // return of(this.ongoingIncidents);
    
    this.OngoingIncidents_API = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/OngoingIncidents"
    return this.http.get<Inc_Details[]>(this.OngoingIncidents_API , this.httpOptions)
    .pipe(
      catchError(this.handle_API_Error<Inc_Details[]>('get_OngoingIncidents_API_response', []))
    );
  }
 
  /*

  // (alternative) Single function for IBG_API_response
  get_IBG_API_response():Observable<Incident_By_Group_AllIntervals>{
    this.IBG_CurrentMonth_API = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/IBGCurrentMonth"
    this.IBG_Last90Days_API = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/IBGLast3Months"
    let temp: Incident_By_Group_AllIntervals = {IBG_CurrentMonth : [],IBG_Last90Days : []};

    this.http.get<Incident_By_Group[]>(this.IBG_CurrentMonth_API , this.httpOptions).subscribe((x)=>{
      console.log("subscribed IBG_CurrentMonth: "+ x);
      temp.IBG_CurrentMonth = x;
    }

    );
    this.http.get<Incident_By_Group[]>(this.IBG_Last90Days_API , this.httpOptions).subscribe((x)=>{
      console.log("subscribed IBG_Last90Days: "+ x);
      temp.IBG_Last90Days =x;
    }

    );

    console.log("IBG_CurrentMonth: "+ temp.IBG_CurrentMonth);
    console.log("IBG_Last90Days: "+ temp.IBG_Last90Days );

    return of(temp);
  }
  */


  get_IBG_API_CurrentMonth_response():Observable<Incident_By_Group[]>{
    this.IBG_CurrentMonth_API = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/IBGCurrentMonth"

    return this.http.get<Incident_By_Group[]>(this.IBG_CurrentMonth_API , this.httpOptions)
    .pipe(
      catchError(this.handle_API_Error<Incident_By_Group[]>('get_IBG_API_CurrentMonth_response', []))
    );
  }
  get_IBG_API_Last90Days_response():Observable<Incident_By_Group[]>{
    this.IBG_Last90Days_API = "http://maznaddbd01/MIAPI/api/MajorIncidentAPI/IBGLast3Months"

    return this.http.get<Incident_By_Group[]>(this.IBG_Last90Days_API , this.httpOptions)
    .pipe(
      catchError(this.handle_API_Error<Incident_By_Group[]>('get_IBG_API_Last90Days_response', []))
    );
  }
  get_LastTenOutages_API_response():Observable<Incident_Outages[]>{

    this.LastTenOutages_API = this.baseURL + "LastTenOutages";

    return this.http.get<Incident_Outages[]>(this.LastTenOutages_API , this.httpOptions)
    .pipe(
      catchError(this.handle_API_Error<Incident_Outages[]>('get_LastTenOutages_API_response', []))
    );
  }
  handle_API_Error<T>(operation = 'operation', result?: T){
    return (error: any): Observable<T> => {
      
      // TODO: send the error to remote logging infrastructure
      console.error(`API error:${error}`); // log to console instead

      if(operation==="get_TIT_API_response"){
        console.error(`API operation:${operation}`);
        this.TIT_API_error_event.next();
      }

      if(operation==="get_OngoingIncidents_API_response"){
        console.error(`API operation:${operation}`);
        this.OngoingIncidents_API_error_event.next();
      }

      // TODO: better job of transforming error for user consumption
      //this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);

    }

  }
}
