import { AfterViewChecked, AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import {NGXLogger} from 'ngx-logger';
import { Subscription } from 'rxjs';
import {DigitalDashboardDataService} from '../digital-dashboard-data.service';

//imports jquery    
declare var $: any;


interface Inc_Details {
  incidentNumber : string;
  priority : string;
  state : string;
  regionsImpacted:string; 
  shortDescription: string;
}

@Component({
  selector: 'app-ongoing-incidents',
  templateUrl: './ongoing-incidents.component.html',
  styleUrls: ['./ongoing-incidents.component.css']
})
export class OngoingIncidentsComponent implements 
OnInit,AfterViewInit,AfterViewChecked,OnDestroy {
  priority_1_Incidents :Inc_Details[]=[];
  priority_2_Incidents :Inc_Details[]=[];
  ongoingIncidents :Inc_Details[]=[];
  no_MI_reported:boolean=true;
  no_MI_info_text:string;
  count_p1_incidents:number;count_p2_incidents:number;  
  carousel_req_p1_indices:number[]=[];carousel_req_p2_indices:number[]=[];
  dboard_dataService_subscription : Subscription;
  dboard_dataService_error_subscription : Subscription;
  dboard_dataService_api_subscription : Subscription;

  chartTitle:string="Ongoing Incidents";
  show_P1_Incident:boolean=true;
  is_OngoingIncidents_API_error:boolean=false;

  @ViewChild('mycarouselControls') mycarouselControls : ElementRef;

  constructor(private logger: NGXLogger, private dboard_dataService: DigitalDashboardDataService) { 

        /* Deprecated code to be removed
        // update data when component is intialized
        this.ongoingIncidents = this.dboard_dataService.ongoingIncidents;
        */
  }


  ngOnInit(): void {

    this.no_MI_info_text = "We are constantly monitoring the performance and availabilty of \
    Global IT infrastructure. We will post you should there be any interruptions in service. \
    If you are experiencing any major issues/ outages that have not been logged please contact ADM Service Desk";

    /* Deprecated code to be removed
    this.ongoingIncidents = this.dboard_dataService.ongoingIncidents;
    */
    this.refreshChart();
  }
  ngAfterViewInit(): void {

    this.logger.debug("At OngoingIncidentsComponent - ngAfterViewInit");

    // subscribe to get update data on updatedData_event
    this.dboard_dataService_subscription = this.dboard_dataService.get_updatedData_event.subscribe(() => {
      
      //
      this.is_OngoingIncidents_API_error = false;
      this.ongoingIncidents =[];
      if(this.dboard_dataService_api_subscription){
        this.dboard_dataService_api_subscription.unsubscribe(); 
      }     
      //
      this.dboard_dataService_api_subscription = this.dboard_dataService.get_OngoingIncidents_API_response().subscribe((ongoingIncidents)=>{
        this.ongoingIncidents = ongoingIncidents;
        this.refreshChart();

      });

    });

    //subscribe to get OngoingIncidents API error
    this.dboard_dataService_error_subscription = this.dboard_dataService.OngoingIncidents_API_error_event.subscribe(()=>{
      this.is_OngoingIncidents_API_error = true;
      this.logger.debug(`is_OngoingIncidents_API_error:${this.is_OngoingIncidents_API_error}`);
    });
    

    // call next slides in carousel every 4 seconds
    setInterval(function(){
    $('#p1_carouselControls').carousel('next');
    $('#p2_carouselControls').carousel('next'); }, 10000);
    

    // Toggle Region/Global
    setInterval(()=>{ 
      if(this.show_P1_Incident){
        this.selectPriority('Priority_Two');
        } else{
        this.selectPriority('Priority_One');    
        } 
      },30000);
  }
  ngAfterViewChecked(): void{
    //$('.carousel').carousel()
    //$('.mycarouselControls').carousel()
    //$('mycarouselControls').carousel()
    //$('#mycarouselControls').carousel()

  }
  refreshChart(){
    if(!this.is_OngoingIncidents_API_error){
      this.loadData();

    }
    

  }
  selectPriority(priority:string){
    if(priority=="Priority_One"){
      this.show_P1_Incident=true;
     // $('#mycarouselControls').carousel()
      this.logger.debug("selectPriority : Priority_One");

    }else{
      this.show_P1_Incident=false;
      //$('#p2_carouselControls').carousel()
      this.logger.debug("selectPriority : Priority_Two");

    }

  }
  loadData(){
    this.priority_1_Incidents=[];
    this.priority_2_Incidents=[];
    if(this.ongoingIncidents.length>0){
      this.no_MI_reported=false;

      for (let incDetails of this.ongoingIncidents) {
        if(incDetails.priority=="1 - Critical"){
          this.priority_1_Incidents.push(incDetails);
  
        }else if(incDetails.priority=="2 - High"){
          this.priority_2_Incidents.push(incDetails);
  
        }
  
      }

      this.count_p1_incidents=this.priority_1_Incidents.length;
      this.count_p2_incidents=this.priority_2_Incidents.length;
      this.carousel_req_p1_indices=[];
      this.carousel_req_p2_indices=[];
      for(var i=0;(3*i)<this.count_p1_incidents;i++){
        this.carousel_req_p1_indices.push(3*i);
        //this.logger.debug(`carousel_req_p1_indices : ${2*i}`);
      
      }
      this.logger.debug(`carousel_req_p1_indices length: ${this.carousel_req_p1_indices.length}`);
  
      for(var i=0;(3*i)<this.count_p2_incidents;i++){
        this.carousel_req_p2_indices.push(3*i);
      
      }

    }
    
      
  }
  start_carousel(){
    $('#mycarouselControls').carousel()
    
    //this.logger.debug(`mycarouselControls native element: ${this.mycarouselControls.nativeElement}`);
    //this.logger.debug(`mycarouselControls jquery element: ${$('#mycarouselControls')}`);
    //$('#p2_carouselControls').carousel()
    //this.mycarouselControls.nativeElement.carousel();
  }
  ngOnDestroy(): void {
    this.dboard_dataService_subscription.unsubscribe();
    this.dboard_dataService_error_subscription.unsubscribe();
  }

}
