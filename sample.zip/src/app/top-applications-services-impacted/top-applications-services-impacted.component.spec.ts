import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopApplicationsServicesImpactedComponent } from './top-applications-services-impacted.component';

describe('TopApplicationsServicesImpactedComponent', () => {
  let component: TopApplicationsServicesImpactedComponent;
  let fixture: ComponentFixture<TopApplicationsServicesImpactedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopApplicationsServicesImpactedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopApplicationsServicesImpactedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
