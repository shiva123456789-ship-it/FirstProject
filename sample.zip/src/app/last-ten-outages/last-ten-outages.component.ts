import { Component, OnInit } from '@angular/core';


import {NGXLogger} from 'ngx-logger';
import {DigitalDashboardDataService} from '../digital-dashboard-data.service';

//imports jquery    
declare var $: any;

interface Incident_Outages {
  incidentNumber : string;
  priority : string;
  regionsImpacted:string;
  impactedServices:string;
  
}

@Component({
  selector: 'app-last-ten-outages',
  templateUrl: './last-ten-outages.component.html',
  styleUrls: ['./last-ten-outages.component.css']
})
export class LastTenOutagesComponent implements OnInit {


  title:string="Last 10 Outages/Service Interuptions"; //Top 5 Applications/Services Impacted
  LastTenOutage_data: Incident_Outages[] = [];
  tempArray:number[] = [1,2,3,4,5,6,7,8,9,10];
  carousel_req_tempArray_indices = [0,5];
  constructor(private logger: NGXLogger, 
    private dboard_dataService: DigitalDashboardDataService) { }

  ngOnInit(): void {
  }
  ngAfterViewInit(): void {
         // request to get update data on updatedData_event
         this.dboard_dataService.get_updatedData_event.subscribe(() => {
          this.logger.debug("subscribed - get_updatedData_event"); 
          
          this.LastTenOutage_data = [];
          this.dboard_dataService.get_LastTenOutages_API_response().subscribe((LastTenOutage_data)=>{
            this.LastTenOutage_data = LastTenOutage_data;  
          });
          
    
         });

             // call next slides in carousel every 4 seconds
    //  setInterval(function(){
    //    $('#outages_carouselControls').carousel('next');
    //    console.log("why running so fast"); 
    //     }, 20000);
  }


}
