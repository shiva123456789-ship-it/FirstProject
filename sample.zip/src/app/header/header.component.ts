import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  title:string;
  copmany_logo_img_path:string;
  calendar_img_path:string;
  today: number = Date.now();
  
  constructor() { 
    this.title="Major Incidents Dashboard";
    this.copmany_logo_img_path="../../assets/images/ADM Logo 180 (2).png";
    this.calendar_img_path="../../assets/images/header-calendar.jpg"

  }

  ngOnInit(): void {
    
    setInterval(()=>{ this.today= Date.now(); }, 3600000);

  }

}
