//Core
import { Component, OnDestroy, OnInit, Testability } from '@angular/core';
import { number } from '@amcharts/amcharts4/core';
//Services
import { NGXLogger } from 'ngx-logger';
import {DigitalDashboardDataService} from '../digital-dashboard-data.service';
//Assets
import {MapWithPulsatingBullets_2} from '../../assets/ts/map_with_pulsating_bullets_2';
import {disposeAmchartById_2} from '../../assets/ts/amchart_maintenance_2';
import { Subscription } from 'rxjs';




// declare function disposeAmchartById(id:any);
// declare function loadIncidentsByRegion(includeRegion:any,incidentsDetails:any);


interface Inc_Details {
  incidentNumber : string;
  priority : string;
  state : string;
  regionsImpacted:string; 
  shortDescription: string;
}

@Component({
  selector: 'app-incidents-by-region-globally',
  templateUrl: './incidents-by-region-globally.component.html',
  styleUrls: ['./incidents-by-region-globally.component.css']
})
export class IncidentsByRegionGloballyComponent implements OnInit,OnDestroy {


  //global_chartId:number;na_chartId:number;sa_chartId:number;apac_chartId:number;eu_chartId:number;
  global_chartId:any;na_chartId:any;sa_chartId:any;apac_chartId:any;eu_chartId:any;
  showing_chart_byRegion:boolean=false;
  ongoingIncidentDetails:Inc_Details[]=[];
  newIncidentDetails_available:boolean=false;
  ongoingIncidentDetails_NA:Inc_Details[]=[];ongoingIncidentDetails_SA:Inc_Details[]=[];
  ongoingIncidentDetails_APAC:Inc_Details[]=[];ongoingIncidentDetails_EMEA:Inc_Details[]=[];
  ongoingIncidentDetails_Global:Inc_Details[]=[];
 
  ongoingIncidentDetails_NA_count:number;ongoingIncidentDetails_SA_count:number;
  ongoingIncidentDetails_APAC_count:number;ongoingIncidentDetails_EMEA_count:number;
  ongoingIncidentDetails_Global_count:number;

  chart_MPB : MapWithPulsatingBullets_2;
  display_style_regional:string="block";
  display_style_global:string="none";
  global_p1_count:number;global_p2_count:number;
  na_p1_count:number;sa_p1_count:number;eu_p1_count:number;apac_p1_count:number;
  na_p2_count:number;sa_p2_count:number;eu_p2_count:number;apac_p2_count:number;
  dboard_dataService_subscription : Subscription;
  dboard_dataService_api_subscription : Subscription;
  dboard_dataService_error_subscription : Subscription;

  is_OngoingIncidents_API_error:boolean=false;
  


  constructor(private logger: NGXLogger, private dboard_dataService: DigitalDashboardDataService) { 

  }


  ngOnInit(): void {

    this.chart_MPB = new MapWithPulsatingBullets_2();
     // update data when component is intialized
     this.ongoingIncidentDetails = this.dboard_dataService.ongoingIncidents;

     /* Deprecated code to be removed
     //loding (adding) data for charts
     //this.updateRegions_IncidentDetails();
     */
       
  }

  ngOnDestroy(): void {
    this.dboard_dataService_subscription.unsubscribe();
  }


  ngAfterViewInit(): void{   
    
    /* Deprecated code to be removed
    // update data when api's are called
    this.dboard_dataService_subscription = this.dboard_dataService.ongoingIncidents_UpdatedEvent.subscribe(() => {
        this.logger.debug("At ongoingIncidents_UpdatedEvent");
        this.ongoingIncidentDetails = this.dboard_dataService.ongoingIncidents;

        //loding (adding) data for charts
        this.updateRegions_IncidentDetails();

       
    });
    */

   // subscribe to get update data on updatedData_event
   this.dboard_dataService_subscription = this.dboard_dataService.get_updatedData_event.subscribe(()=>{
    
    //
    this.is_OngoingIncidents_API_error = false;
    this.ongoingIncidentDetails =[];


    if(this.dboard_dataService_api_subscription){
      this.dboard_dataService_api_subscription.unsubscribe(); 
    }
    
    //
    this.dboard_dataService_api_subscription = this.dboard_dataService.get_OngoingIncidents_API_response().subscribe((ongoingIncidents)=>{
      this.ongoingIncidentDetails = ongoingIncidents;
      
      //loding (adding) data for charts
      this.updateRegions_IncidentDetails();
    });

   });

   //subscribe to get OngoingIncidents API error
      this.dboard_dataService_error_subscription = this.dboard_dataService.OngoingIncidents_API_error_event.subscribe(()=>{
      this.is_OngoingIncidents_API_error = true;
      this.logger.debug(`is_OngoingIncidents_API_error:${this.is_OngoingIncidents_API_error}`);
    });

    // Toggle Region/Global
    setInterval(
      ()=>{ 
        if(this.showing_chart_byRegion){
          this.selectRegion('incidents_by_global');
        } else{
          this.selectRegion('incidents_by_region');

        } 
      }
    ,45000);    
    
  }


  updateRegions_IncidentDetails(){

    this.logger.debug("At IncidentsByRegionGloballyComponent - updateRegions_IncidentDetails:");
    this.ongoingIncidentDetails_NA=[];this.ongoingIncidentDetails_SA=[];this.ongoingIncidentDetails_APAC=[];
    this.ongoingIncidentDetails_EMEA=[];this.ongoingIncidentDetails_Global=[];
    this.global_p1_count=0;this.global_p2_count=0;

    this.logger.debug(`ongoingIncidentDetails length: ${this.ongoingIncidentDetails.length}`);
    for (let incident_n_details of this.ongoingIncidentDetails) {
      this.logger.debug(`incident_n_details.regionsImpacted: ${incident_n_details.regionsImpacted}`);

      if(incident_n_details.regionsImpacted){
        let regionsImpacted_array= incident_n_details.regionsImpacted.split(",");
        for(let contains_region of regionsImpacted_array){
          this.logger.debug(`contains_region: ${contains_region}`);

          contains_region = contains_region.trim();
  
          switch (contains_region) {
            case "North America":
              this.ongoingIncidentDetails_NA.push(incident_n_details);
              break;
            case "South America":
              this.ongoingIncidentDetails_SA.push(incident_n_details);
              break;
            case "APAC":
              this.ongoingIncidentDetails_APAC.push(incident_n_details);
              break;
            case "EMEA":
              this.ongoingIncidentDetails_EMEA.push(incident_n_details);
              break;
            case "GLOBAL":
              this.ongoingIncidentDetails_Global.push(incident_n_details);
              if(incident_n_details.priority=="1 - Critical"){
                this.global_p1_count++
    
              }
              else if(incident_n_details.priority=="2 - High"){
                this.global_p2_count++
    
              }       
            
              break;
            default:
              console.log(`No such region exists!`);
              break;
    
          }
        }
      }
    }
    /*
    this.ongoingIncidentDetails_NA_count;
    this.ongoingIncidentDetails_SA_count;
    this.ongoingIncidentDetails_APAC_count;
    this.ongoingIncidentDetails_EMEA_count;
    this.ongoingIncidentDetails_Global_count;
    */
    this.newIncidentDetails_available=true;
    this.selectRegion("incidents_by_region");


  }


  selectRegion(region:string){
    if((region=="incidents_by_global") && (this.showing_chart_byRegion)){


        this.showing_chart_byRegion=!this.showing_chart_byRegion;
        this.display_style_regional="none";
        this.display_style_global="";

        this.logger.debug("Disposing regional charts");
        // disposeAmchartById(this.na_chartId);
        // disposeAmchartById(this.sa_chartId);
        // disposeAmchartById(this.apac_chartId);
        // disposeAmchartById(this.eu_chartId);

        disposeAmchartById_2(this.na_chartId);
        disposeAmchartById_2(this.sa_chartId);
        disposeAmchartById_2(this.apac_chartId);
        disposeAmchartById_2(this.eu_chartId);


        //this.global_chartId=loadIncidentsByRegion("global",this.ongoingIncidentDetails_Global);
        this.global_chartId=this.chart_MPB.loadIncidentsByRegion_2("global",this.ongoingIncidentDetails_Global, 2);
        this.logger.debug(`Global_id: ${this.global_chartId}`);        

      
    }
     else if(
       ((region=="incidents_by_region") && (!this.showing_chart_byRegion))||
       (this.newIncidentDetails_available))  {
       //all, northAmerica,southAmerica,europe,asia
 

        //disposeAmchartById(this.global_chartId);
        this.logger.debug("showing_chart_byRegion:"+this.showing_chart_byRegion);
        disposeAmchartById_2(this.global_chartId);
        if(this.showing_chart_byRegion){
          this.logger.debug("Disposing regional charts");
          disposeAmchartById_2(this.na_chartId);
          disposeAmchartById_2(this.sa_chartId);
          disposeAmchartById_2(this.apac_chartId);
          disposeAmchartById_2(this.eu_chartId);

        }
        else{
          this.showing_chart_byRegion=!this.showing_chart_byRegion;
        }

        
        this.display_style_regional="";
        this.display_style_global="none";

        // this.na_chartId= function () {
        //   return this.chart_MPB.loadIncidentsByRegion_2("northAmerica",this.ongoingIncidentDetails_NA, 0);
        // }

        this.na_chartId= this.chart_MPB.loadIncidentsByRegion_2("northAmerica",this.ongoingIncidentDetails_NA, 2);
        this.sa_chartId=this.chart_MPB.loadIncidentsByRegion_2("southAmerica",this.ongoingIncidentDetails_SA, 4);
        this.apac_chartId=this.chart_MPB.loadIncidentsByRegion_2("europe",this.ongoingIncidentDetails_EMEA, 4);
        this.eu_chartId=this.chart_MPB.loadIncidentsByRegion_2("apac",this.ongoingIncidentDetails_APAC, 4);
        this.logger.debug(`NA_id: ${this.na_chartId},SA_id: ${this.sa_chartId},APAC_id: ${this.apac_chartId},EU_id: ${this.eu_chartId}`);
      
     }
     this.newIncidentDetails_available=false;   

  }

  


}
