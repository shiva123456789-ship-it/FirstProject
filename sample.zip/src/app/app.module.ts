import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MajorIncidentsThisMonthComponent } from './major-incidents-this-month/major-incidents-this-month.component';
import { DaysSinceMiReportedComponent } from './days-since-mi-reported/days-since-mi-reported.component';
import { OngoingIncidentsComponent } from './ongoing-incidents/ongoing-incidents.component';
import { IncidentsByGroupComponent } from './incidents-by-group/incidents-by-group.component';
import { TotalIncidentsTrendComponent } from './total-incidents-trend/total-incidents-trend.component';
import { TopApplicationsServicesImpactedComponent } from './top-applications-services-impacted/top-applications-services-impacted.component';
import { IncidentsByRegionGloballyComponent } from './incidents-by-region-globally/incidents-by-region-globally.component';
import { HeaderComponent } from './header/header.component';
import { OngoingIncidentDetailsComponent } from './ongoing-incidents/ongoing-incident-details/ongoing-incident-details.component';
import { LastTenOutagesComponent } from './last-ten-outages/last-ten-outages.component';
import { OutageDetailsComponent } from './last-ten-outages/outage-details/outage-details.component';

@NgModule({
  declarations: [
    AppComponent,
    MajorIncidentsThisMonthComponent,
    DaysSinceMiReportedComponent,
    OngoingIncidentsComponent,
    IncidentsByGroupComponent,
    TotalIncidentsTrendComponent,
    TopApplicationsServicesImpactedComponent,
    IncidentsByRegionGloballyComponent,
    HeaderComponent,
    OngoingIncidentDetailsComponent,
    LastTenOutagesComponent,
    OutageDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    LoggerModule.forRoot({level: NgxLoggerLevel.DEBUG, 
    serverLogLevel: NgxLoggerLevel.ERROR,disableConsoleLogging: false})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
