import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OngoingIncidentsComponent } from './ongoing-incidents.component';

describe('OngoingIncidentsComponent', () => {
  let component: OngoingIncidentsComponent;
  let fixture: ComponentFixture<OngoingIncidentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OngoingIncidentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OngoingIncidentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
