import * as am4core from "@amcharts/amcharts4/core";

export function disposeAmchartById_2(id) {
    var charts = am4core.registry.baseSprites;
    for(var i = 0; i < charts.length; i++) {
      if (charts[i].baseId == id) {
        charts[i].dispose();
      }
    }
  }