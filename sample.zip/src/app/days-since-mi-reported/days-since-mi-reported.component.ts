import { AfterViewInit, Component, OnInit } from '@angular/core';
import {NGXLogger} from 'ngx-logger';
import {DigitalDashboardDataService} from '../digital-dashboard-data.service';

interface Last_MI_Details {
  priority : string;
  days_count : number;
  value: string;
}

@Component({
  selector: 'app-days-since-mi-reported',
  templateUrl: './days-since-mi-reported.component.html',
  styleUrls: ['./days-since-mi-reported.component.css']
})
export class DaysSinceMiReportedComponent implements 
OnInit,AfterViewInit {

  title:string="Days since last Major Incident Reported";
  last_MI_Details:Last_MI_Details[];
  priority_1 : Last_MI_Details;
  priority_2 : Last_MI_Details;
  heading_priority_1: string;
  heading_priority_2: string;
  caution_imagePath: string;
  dummy_p1_graph_imgPath:string;
  dummy_p2_graph_imgPath:string;

  constructor(private logger: NGXLogger, 
    private dboard_dataService: DigitalDashboardDataService) {
    this.heading_priority_1 ="Priority 1";
    this.heading_priority_2 ="Priority 2";
   }


  ngOnInit(): void {
    this.dummy_p1_graph_imgPath="../../assets/images/Priority1_legendImage.png";

    this.dummy_p2_graph_imgPath="../../assets/images/Priority2_legendImage.png";

    this.caution_imagePath="../../assets/images/calendar banner_1_42x180.png" 
    //calendar banner_1_42x180.png

  }
  ngAfterViewInit(): void {
    this.dboard_dataService.get_updatedData_event.subscribe(()=>{
      this.dboard_dataService.get_DSLMI_API_response().subscribe((last_MI_Details)=>{
        this.last_MI_Details = last_MI_Details;
        this.refreshChart();

      });
    });
  }
  refreshChart():void{
    this.loadData();
  }
  loadData():void{
    for (let miDays of this.last_MI_Details) {


      if(miDays.priority=='1 - Critical'){

        this.priority_1=miDays;
      }
      else if(miDays.priority==="2 - High"){
 
        this.priority_2=miDays;
      }
      
    }
  }

}
