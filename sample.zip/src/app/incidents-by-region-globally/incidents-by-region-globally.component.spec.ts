import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncidentsByRegionGloballyComponent } from './incidents-by-region-globally.component';

describe('IncidentsByRegionGloballyComponent', () => {
  let component: IncidentsByRegionGloballyComponent;
  let fixture: ComponentFixture<IncidentsByRegionGloballyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncidentsByRegionGloballyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncidentsByRegionGloballyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
