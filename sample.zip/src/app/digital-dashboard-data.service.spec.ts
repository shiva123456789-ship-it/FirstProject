import { TestBed } from '@angular/core/testing';

import { DigitalDashboardDataService } from './digital-dashboard-data.service';

describe('DigitalDashboardDataService', () => {
  let service: DigitalDashboardDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DigitalDashboardDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
