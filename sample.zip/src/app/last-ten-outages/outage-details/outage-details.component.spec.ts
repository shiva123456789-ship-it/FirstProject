import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutageDetailsComponent } from './outage-details.component';

describe('OutageDetailsComponent', () => {
  let component: OutageDetailsComponent;
  let fixture: ComponentFixture<OutageDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutageDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutageDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
