import { Component, Input, OnInit } from '@angular/core';
//import {x} '../../../assets/images/NotationImage.JPG';
//src\assets\images\NotationImage.JPG

interface Inc_Details {
  incidentNumber : string;
  priority : string;
  state : string;
  regionsImpacted:string; 
  shortDescription: string;
}

@Component({
  selector: 'app-ongoing-incident-details',
  templateUrl: './ongoing-incident-details.component.html',
  styleUrls: ['./ongoing-incident-details.component.css']
})
export class OngoingIncidentDetailsComponent implements OnInit {
  @Input() incidentDetails : Inc_Details;
  warning_imagePath:string;
  

  constructor() { }

  ngOnInit(): void {
    this.warning_imagePath ='../../../assets/images/Caution_1_40x40.jpg'; //dummy caution.jpg, NotationImage.JPG
    console.log("At OngoingIncidentDetailsComponent");
  }

}
