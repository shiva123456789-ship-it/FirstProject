import { AfterViewInit, Component, OnInit } from '@angular/core';

import { LineChart } from '../../assets/ts/linechart';
// import { LineChart } from "../../assets/js/lineChart.js"
import { disposeAmchartById_2 } from '../../assets/ts/amchart_maintenance_2';

//
import { Subscription } from 'rxjs';

//
//AmchartLicenseCheck -> to be remved if not required
import { AmchartLicenseCheck } from '../../assets/ts/amchart-license-check';
import { NGXLogger } from 'ngx-logger';
import { DigitalDashboardDataService } from '../digital-dashboard-data.service';


interface Total_Incidents_Trend {
  month: string;
  priority1: number;
  priority2: number;

}

@Component({
  selector: 'app-total-incidents-trend',
  templateUrl: './total-incidents-trend.component.html',
  styleUrls: ['./total-incidents-trend.component.css']
})
export class TotalIncidentsTrendComponent implements OnInit, AfterViewInit {
  chartTitle: string = "Total Incidents Trend";
  lineChart: LineChart = new LineChart();
  totalIncidentsTrend_data: Total_Incidents_Trend[];
  chart_ALC: AmchartLicenseCheck;
  averageIncidents: number = 0;
  is_TIT_API_error: boolean = false;
  TIT_chartIds: number[] = [];
  dboard_dataService_subscription: Subscription;
  dboard_dataService_error_subscription: Subscription;

  constructor(private logger: NGXLogger,
    private dboard_dataService: DigitalDashboardDataService) { }

  ngOnInit(): void {


  }
  ngAfterViewInit(): void {
    //this.chart_ALC = new AmchartLicenseCheck();
    //this.chart_ALC.licenseLoad();

    // var lineChart = new LineChart();
    // lineChart.loadIncdents();

    //lineChart=null;

    // subscribe to get update data on updatedData_event
    this.dboard_dataService_subscription = this.dboard_dataService.get_updatedData_event.subscribe(() => {

      /* Temp debug code
      this.logger.debug("TotalIncidentsTrendComponent subscribed - get_updatedData_event");
      */

      this.is_TIT_API_error = false;

      this.dboard_dataService.get_TIT_API_response().subscribe((totalIncidentsTrend) => {

        this.logger.debug("subscribed - get_TIT_API_response");
        /* Temp debug code
        this.logger.debug(`${totalIncidentsTrend}`);
        */
        this.totalIncidentsTrend_data = totalIncidentsTrend;
        this.refreshChart();
        this.calculateAvg(this.totalIncidentsTrend_data, 'priority1', 'priority2');

      });
      /*


      let MI_count = this.totalIncidentsTrend[0];
      */




    });

    // subscribe to get API error
    this.dboard_dataService_error_subscription = this.dboard_dataService.TIT_API_error_event.subscribe(() => {
      this.is_TIT_API_error = true;
      this.logger.debug(`is_TIT_API_error:${this.is_TIT_API_error}`);

    })

  }
  refreshChart(): void {
    if (!this.is_TIT_API_error) {

      /* Temp debug code
      this.logger.debug(`MI_count: ${this.totalIncidentsTrend_data}`);
      for(let MI_count of this.totalIncidentsTrend_data){
        this.logger.debug(`MI_count: ${MI_count.month + " " + MI_count.priority1 + " "  + MI_count.priority2}`); 
      }
      */

      this.TIT_chartIds.forEach(chartId => disposeAmchartById_2(chartId))
      this.TIT_chartIds = [];
      this.TIT_chartIds = this.lineChart.generateChart(this.totalIncidentsTrend_data);
    }


  }

  ngOnDestroy(): void {
    this.dboard_dataService_subscription.unsubscribe();
    this.dboard_dataService_error_subscription.unsubscribe();
  }

  calculateAvg(data, label1, label2): void {
    // console.log("checking callback for " + label1, label2);

    // console.log(data[0][label]);

    let sum = 0;

    console.log("Running average function");

    for (var i = 0; i < data.length; i++) {
      sum += parseInt(data[i][label1], 10) + parseInt(data[i][label2], 10); //don't forget to add the base
      console.log(data[i][label1]);
    }

    console.log("sum is " + sum);

    let avg = 0;
    avg = Math.round(sum / data.length);

    console.log("avg is " + avg);
    console.log("CHECKING AVERAG CALLBACK :" + avg);
    console.log(data);

    // if(avg === parseInt(avg, 10))
    //     TotalIncidentsTrendComponent.calculateAvg(avg);
    this.setAverage(avg);
    return;
  }

  setAverage(avg): void {
    console.log("Average function called");
    this.averageIncidents = avg;
  }


}
