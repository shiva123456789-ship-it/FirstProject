import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DigitalDashboardDataService } from './digital-dashboard-data.service';
import {NGXLogger} from 'ngx-logger';
import { Observable, of, Subject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit{
  title = 'major-incidents-dashboard';
  public get_updatedData_event = new Subject();

  constructor(private dboard_dataService: DigitalDashboardDataService,
    private titleService: Title,private logger: NGXLogger) {
    
    this.titleService.setTitle( "ADM MI-Dashboard" );

    /* Deprecated code to be removed
    // load data the first time
    this.dboard_dataService.call_digitalDashboard_APIs();
    */


    
 
  }

  ngOnInit(): void {  

    //this.dboard_dataService.get_DSLMI_API_response();

  }
  ngAfterViewInit(): void {
    
    
    this.logger.debug("At AppComponent - ngAfterViewInit -in");
    
    // call to notify the compents to get updated data
    this.dboard_dataService.updateDataCall();

    // call to notify the compents to get updated data on every 2.5 minutes
    setInterval(() => {
      this.dboard_dataService.updateDataCall();
      
    }, 1500000); 
    
    // reload data on every 2.5 minutes
    /* setInterval(() => {
          this.dboard_dataService.call_digitalDashboard_APIs()
    }, 90000);  */
    
    
    
    
    this.logger.debug("At AppComponent - ngAfterViewInit -out");
    
  }

  /* ngAfterViewChecked(): void {
     this.logger.debug("At AppComponent - ngAfterViewChecked");
   } */


}
