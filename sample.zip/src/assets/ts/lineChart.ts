/* Imports */
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

import * as am4maps from "@amcharts/amcharts4/maps";
import am4geodata_worldLow from "@amcharts/amcharts4-geodata/worldLow";

export class LineChart {

    calculateAvg(data, label1, label2) {
        // console.log("checking callback for " + label1, label2);

        // console.log(data[0][label]);

        let sum = 0;

        console.log("Running average function");

        for (var i = 0; i < data.length; i++) {
            sum += parseInt(data[i][label1], 10) + parseInt(data[i][label2], 10); //don't forget to add the base
            // console.log(data[i][label]);
        }

        console.log("sum is " + sum);

        let avg = 0;
        avg = sum / data.length;

        console.log("avg is " + avg);
        console.log("CHECKING AVERAG CALLBACK :" + avg);
        console.log(data);

        // if(avg === parseInt(avg, 10))
        //     // TotalIncidentsTrendComponent.calculateAvg(avg);
        //     return avg;

        return avg;
    }

    //static generateChart(chartdiv) {
    generateChart(totalIncidentsTrend_data) {
        /* Chart code */
        // Themes begin
        am4core.useTheme(am4themes_animated);
        am4core.addLicense("CH213722778");
        // Themes end

        console.log("CHECK CHECK");
        console.log(totalIncidentsTrend_data);

        // totalIncidentsTrend_data = [{"month":"2020-03","priority1":"4","priority2":"14"},{"month":"2020-04","priority1":"4","priority2":"14"},{"month":"2020-05","priority1":"6","priority2":"14"},{"month":"2020-06","priority1":"2","priority2":"14"}];

        //
        let chartIds = [];
        // Create chart instance
        let chart = am4core.create("total_incidents_trend", am4charts.XYChart);

        // Add data
        chart.data = [{
            "date": "2020-01-01",
            "priority1": "5",
            "priority2": "20"
        }, {
            "date": "2020-02-02",
            "priority1": "20",
            "priority2": "75"
        }, {
            "date": "2020-03-03",
            "priority1": "5",
            "priority2": "25"
        },
        {
            "date": "2020-04-03",
            "priority1": "20",
            "priority2": "15"
        },
        {
            "date": "2020-05-03",
            "priority1": "5",
            "priority2": "30"
        },
        {
            "date": "2020-06-03",
            "priority1": "5",
            "priority2": "30"
        },
        {
            "date": "2020-07-01",
            "priority1": "5",
            "priority2": "20"
        }, {
            "date": "2020-08-02",
            "priority1": "20",
            "priority2": "75"
        }, {
            "date": "2020-09-03",
            "priority1": "5",
            "priority2": "25"
        },
        {
            "date": "2020-10-03",
            "priority1": "20",
            "priority2": "15"
        },
        {
            "date": "2020-11-03",
            "priority1": "5",
            "priority2": "30"
        },
        {
            "date": "2021-2-03",
            "priority1": "5",
            "priority2": "30"
        }
        ];


        chart.data = totalIncidentsTrend_data;
        this.calculateAvg(chart.data, "priority1", "priority2");



        chart.height = am4core.percent(100);

        // Create axes
        let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        dateAxis.renderer.grid.template.location = 0;
        dateAxis.renderer.minGridDistance = 50;
        dateAxis.renderer.grid.template.disabled = true;

        //Add padding to chart to display dates
        chart.paddingRight = 65;
        // chart.paddingLeft = 200;

        dateAxis.dateFormats.setKey("month", "MMM yy");
        dateAxis.periodChangeDateFormats.setKey("month", "MMM yy");
        // dateAxis.dateFormats.setKey("year", "yy");

        dateAxis.gridIntervals.setAll([
            { timeUnit: "month", count: 1 }
        ]);

        dateAxis.renderer.labels.template.rotation = 45;
        dateAxis.renderer.labels.template.horizontalCenter = "left";
        dateAxis.renderer.labels.template.fontSize = 15;

        dateAxis.startLocation = 0.45;
        dateAxis.endLocation = 0.5;

        let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        // valueAxis.logarithmic = true;
        valueAxis.renderer.minGridDistance = 30;
        valueAxis.renderer.grid.template.disabled = true;

        // Create series 1
        let series = chart.series.push(new am4charts.LineSeries());
        series.name = "Priority 1";
        series.dataFields.valueY = "priority1";
        // series.dataFields.valueY = "kmart";
        series.dataFields.dateX = "month";
        series.tensionX = .8;
        series.tensionY = 1;

        // //log on
        // valueAxis.logarithmic = true;
        // series.tensionX = .8;
        // series.tensionY = .6;

        series.strokeWidth = 1;
        series.fillOpacity = 0.1;
        series.fill = am4core.color("#ff0404");
        series.stroke = am4core.color("#ff0404");


        // Drop-shaped tooltips
        // series.tooltip.background.cornerRadius = 20;
        // series.tooltip.background.strokeOpacity = 0;
        // series.tooltip.pointerOrientation = "vertical";
        // series.tooltip.label.minWidth = 40;
        // series.tooltip.label.minHeight = 40;
        // series.tooltip.label.textAlign = "middle";
        // series.tooltip.label.textValign = "middle";

        // // bullets indicating data on x axis
        // let bullet = series.bullets.push(new am4charts.CircleBullet());
        // bullet.circle.fill = am4core.color("#fff");
        // bullet.circle.strokeWidth = 3;

        //create dummyData for series 1 to set
        // stroke color for legend marker
        series.dummyData = {
            colorStroke: "#FB7C1A",
            colorFill: "#027DBA",
            colorFlag: true
        };


        // Create series 2
        let series2 = chart.series.push(new am4charts.LineSeries());
        series2.name = "Priority 2";
        series2.dataFields.valueY = "priority2";
        series2.dataFields.dateX = "month";
        series2.tensionX = 0.8;
        series2.strokeWidth = 1;
        series2.fillOpacity = 0.1;
        series2.fill = am4core.color("#ffc404");
        series2.stroke = am4core.color("#ffc404");

        // // bullets indicating data on x axis
        // let bullet2 = series2.bullets.push(new am4charts.CircleBullet());
        // bullet2.circle.fill = am4core.color("#fff");
        // bullet2.circle.strokeWidth = 3;

        //create dummyData for series 2 to set
        // stroke color for legend marker
        series2.dummyData = {
            colorStroke: "#027DBA",
            colorFill: "#FB7C1A",
            colorFlag: true
        };


        //Create Legend
        let legend = chart.legend = new am4charts.Legend();
        // legend.position = "right";
        // legend.reverseOrder = true;
        legend.valign = "top";
        legend.contentAlign = "right";
        legend.maxWidth = 300;
        legend.maxHeight = 20;
        //

        //legend markers
        // chart.legend = new am4charts.Legend();
        legend.useDefaultMarker = true;
        let marker: any = legend.markers.template.children.getIndex(0);
        // legend.markers.template.children.
        marker.width = 20;
        marker.height = 20;
        marker.cornerRadius(12, 12, 12, 12);
        marker.strokeWidth = 4;//4;
        // marker.marginTop = 100;
        // marker.stroke = "#FB7C1A";
        // marker.fill = "none";
        // marker.strokeOpacity = 1;
        // marker.fillOpacity = 0;
        // legend.markers.template.children.getIndex(0).fill = am4core.color("black");
        // marker.fill = am4core.color("#ccc");
        // marker.stroke = am4core.color("#ccc");

        series.hiddenInLegend = true;
        series2.hiddenInLegend = true;

        //Create Dummy empty series 3 and 4 for legend markers to toggle for custom behavior
        let series3 = chart.series.push(new am4charts.LineSeries());
        series3.name = "Priority 1";
        series3.dataFields.valueY = "void";
        series3.dataFields.dateX = "month";
        series3.fill = am4core.color("#ff0404");

        series3.dummyData = {
            colorFill: "#ff0404"
        };

        let series4 = chart.series.push(new am4charts.LineSeries());
        series4.name = "Priority 2";
        series4.dataFields.valueY = "void";
        series4.dataFields.dateX = "month";
        series4.fill = am4core.color("#ffc404");

        series4.dummyData = {
            colorFill: "#ffc404"
        };

        var hideflag = false;
        var hideflag2 = false;

        // //Configure custom behaior for legend toggling
        series3.events.on("hidden", function () {
            if (hideflag) {
                series.show();
                series4.show();
                series2.hide();
            }
            else hideflag = true;
        });

        series3.events.on("shown", function () {
            // hideflag= false;
            series2.show();
        });


        series4.events.on("hidden", function () {
            if (hideflag2) {
                series.hide();
                series2.show();
                series3.show()
            }
            else hideflag2 = true;
        });

        series4.events.on("shown", function () {
            series.show();
        });

        series3.show();
        series4.show();

        // //Sets legnd labels with an underline upon toggling

        chart.legend.labels.template.textDecoration = "none";

        var asLabel = chart.legend.labels.template.states.getKey("active");
        asLabel.properties.textDecoration = "underline";
        asLabel.properties.fill = am4core.color("#000");

        // chart.legend.markers.template.setStateOnChildren = false;



        // let as = legend.markers.template.children.getIndex(0).states.getKey("active");
        // as.adapter.add("fill", function (fill, target) {

        //     console.log("as target");
        //     console.log(target);
        //     // console.log("series 2");
        //     // console.log(series2);
        //     // console.log(series2.isHidden);

        //     // console.log("hideFlag");
        //     // console.log(hideflag);
        //     // if(series3.isHidden)
        //     //     return series3.fill;
        //     // else if(series4.isHidden)
        //     //     return series4.fill;

        //     return fill;

        // });



        //use adapter to set fill color of each legend individually

        // series3.adapter.add("fill", function (fill, target){
        //     if(target.isActive){
        //         console.log("taget is active");
        //         return fill;
        //     }

        //         return fill;
        // } );

        // marker.adapter.add("fill", function (fill, target) {
        //     console.log("fill adapter target");


        //     // console.log(target);
        //     // console.log("is active " + target.isActive);
        //     // console.log("is hidden " + target.isHidden);
        //     // console.log("data context");
        //     if(target.dataItem && target.dataItem.dataContext && target.dataItem.dataContext.dummyData) {
        //         console.log(target.dataItem.dataContext);
        //         console.log(target.dataItem.dataContext.dummyData.colorFill);
        //         return am4core.color(target.dataItem.dataContext.dummyData.colorFill);
        //     }

        //     return fill;

        // });

        // marker.adapter.add("fill", function (fill, target) {
        //     // console.log("target is active:" + target.isActive);
        //     if (target.isActive) {
        //         console.log("marker target");
        //         console.log(target);
        //         console.log(fill);
        //     //     // console.log("Adapter called");
        //     //     if (target.dataItem && target.dataItem.dataContext && target.dataItem.dataContext.dummyData) {
        //     //         // console.log("flag " + target.dataItem.dataContext.dummyData.colorFlag)
        //     //         // if (target.dataItem.dataContext.dummyData.colorFlag) {
        //     //             console.log("Color fill Returned");
        //     //             target.dataItem.dataContext.dummyData.colorFlag = true;
        //     //             // console.log(target.dataItem.dataContext.dummyData.colorFill);
        //     //             return target.dataItem.dataContext.dummyData.colorFill;
        //     //         // } else return fill;
        //     //     }
        //     //     else {
        //     //         // console.log("Stroke Returned");
        //     //         return fill;
        //     //     }
        //     }
        //     // return fill;
        //     // else console.log("target not active, target color is: ");
        // });

        /* Create a separate container to put legend in */
        let legendContainer = am4core.create("totalInicident_legenddiv", am4core.Container);
        // legendContainer.layout = "horizontal";
        legendContainer.width = am4core.percent(100);
        legendContainer.height = am4core.percent(100);
        legend.align = "right";
        // legendContainer.align = "right";
        // // legendContainer.padding = (0,0,0,0);
        // legendContainer.background.fill = am4core.color("#53CCD9");
        legend.parent = legendContainer;

        // Make a panning cursor
        series.tooltipText = "[bold]{valueY}[/]";
        series2.tooltipText = "[bold]{valueY}[/]";
        chart.cursor = new am4charts.XYCursor();
        chart.cursor.behavior = "panX";
        // chart.cursor.xAxis = dateAxis;
        // chart.cursor.snapToSeries = series;

        // Add scrollbar
        // chart.scrollbarX = new am4core.Scrollbar();

        // Add a guide (AVERAGE LINE)
        let range = valueAxis.axisRanges.create();
        //range.value = 30.4;
        range.value = this.calculateAvg(chart.data, "priority1", "priority2");
        range.grid.stroke = am4core.color("#396478");
        // range.grid.stroke = am4core.color("#fb8d38");
        range.grid.strokeWidth = 1;
        range.grid.strokeOpacity = 1;
        range.grid.strokeDasharray = "3,3";
        range.label.inside = true;
        // range.label.text = "Average";
        range.label.fill = range.grid.stroke;
        range.label.verticalCenter = "bottom";

        chartIds.push(chart.baseId);
        chartIds.push(legendContainer.baseId);
        return chartIds;
    }

}