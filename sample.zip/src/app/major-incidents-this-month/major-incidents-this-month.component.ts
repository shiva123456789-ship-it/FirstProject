import { AfterViewChecked, AfterViewInit, Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import {NGXLogger} from 'ngx-logger';
import {DigitalDashboardDataService} from '../digital-dashboard-data.service';



interface Inc_Count {
  name: string;
  priority:string;
  count: number;
}

@Component({
  selector: 'app-major-incidents-this-month',
  templateUrl: './major-incidents-this-month.component.html',
  styleUrls: ['./major-incidents-this-month.component.css']
})

//implements AfterViewChecked,DoCheck,OnChanges 
export class MajorIncidentsThisMonthComponent implements 
OnInit,AfterViewInit{

  title: string = "Major Incidents This Month";
  majorIncidentsThisMonth:Inc_Count[];
  priority_1 : Inc_Count;
  priority_2 : Inc_Count;
  caution_imagePath: string;
  heading_priority_1: string;
  heading_priority_2: string;
  dummy_p1_graph_imgPath:string;
  dummy_p2_graph_imgPath:string;


  constructor(private logger: NGXLogger, 
    private dboard_dataService: DigitalDashboardDataService) {
    



  }


  ngOnInit(): void {
    
    this.logger.debug("At MajorIncidentsThisMonthComponent - ngOnInit");
    
    // update data when component is intialized
    //this.majorIncidentsThisMonth = this.dboard_dataService.majorIncidentsThisMonth;  
    //this.refreshChart();

    this.heading_priority_1 ="Priority 1";
    this.heading_priority_2 ="Priority 2";

    this.dummy_p1_graph_imgPath="../../assets/images/Priority1_legendImage.png";
    this.dummy_p2_graph_imgPath="../../assets/images/Priority2_legendImage.png";
    this.caution_imagePath="../../assets/images/caution banner_1_42x180.png"

  }
  // ngDoCheck(): void {
  //   this.logger.debug("At MajorIncidentsThisMonthComponent - ngDoCheck");
  // }
  ngAfterViewInit(): void {
    this.logger.debug("At MajorIncidentsThisMonthComponent - ngAfterViewInit");

     // request to get update data on updatedData_event
     this.dboard_dataService.get_updatedData_event.subscribe(() => {
      this.logger.debug("subscribed - get_updatedData_event"); 
      
      this.dboard_dataService.get_MITM_API_response().subscribe((mi_thisMonth)=>{
        this.majorIncidentsThisMonth = mi_thisMonth;
        this.refreshChart();
      });
      

     });

     // update data when api's are called
     /*
     this.dboard_dataService.mi_thisMonth_UpdatedEvent.subscribe(() => {
      this.logger.debug("subscribed - mi_thisMonth_UpdatedEvent");         
      this.majorIncidentsThisMonth = this.dboard_dataService.majorIncidentsThisMonth;
      this.refreshChart();
     });
     */

     
    
  }
  // ngAfterViewChecked(): void {
  //   this.logger.debug("At MajorIncidentsThisMonthComponent - ngAfterViewChecked");
  // }
  refreshChart(){
    this.loadData();

  }


  loadData(){
    this.logger.debug("At MajorIncidentsThisMonthComponent - loadData");
    

    /* temp debug code
    console.log(`majorIncidentsThisMonth_2 instance of: ${this.majorIncidentsThisMonth instanceof  Array}`);
    console.log(`majorIncidentsThisMonth[0]: ${this.majorIncidentsThisMonth}`);
    */
 

    for (let miCount of this.majorIncidentsThisMonth) {
      console.log(`miCount: ${miCount +" " + miCount.priority +" "+ ( miCount.priority =='1 - Critical')}`);


      if(miCount.priority=='1 - Critical'){
        console.log(`1 - Critical`);
        this.priority_1=miCount;
      }
      else if(miCount.priority==="2 - High"){
        console.log(`2 - High`);
        this.priority_2=miCount;
      }
      
    }



  }

}
