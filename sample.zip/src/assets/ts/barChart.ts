import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

interface Incident_By_Group {
    assignmentGroup: string;
    assignmentGroupCount: number;
}

export class BarChart {


    generateChart(incidentByGroup_data) {
        console.log("Bar Chart Generated");

        am4core.addLicense("CH213722778");

        let chart = am4core.create("incidents_by_group", am4charts.XYChart);
        chart.hiddenState.properties.opacity = 0; // this creates initial fade-in


        // Add data
        chart.data = [{
            "category_index": 1,
            "assignmentGroup": "GT-I&0",
            "assignmentGroupCount": 0
        }, {
            "category_index": 2,
            "assignmentGroup": "GT-Apps",
            "assignmentGroupCount": 0
        }, {
            "category_index": 3,
            "assignmentGroup": "GT-Security",
            "assignmentGroupCount": 0
        },
        {
            "category_index": 4,
            "assignmentGroup": "GT-DNA",
            "assignmentGroupCount": 0

        }
        ];

        /*
        let itrx: Iterator<Incident_By_Group>  = incidentByGroup_data.values().itr();
        while (itrx.hasNext()) {

        }

        let obj : JSONObject = new JSONObject ();
        let key : JSONArray = object.names ();
        */

        //console.log(incidentByGroup_data);
        incidentByGroup_data.forEach(element => {
            console.log("IBG_data json elements:" + element.assignmentGroup);
            chart.data.forEach(chart_ele => {
                if (chart_ele.assignmentGroup == element.assignmentGroup) {
                    chart_ele.assignmentGroupCount = element.assignmentGroupCount;
                    // on match should break if possible
                }
            });
        });

        // chart.data = incidentByGroup_data
        // chart.dateFormatter.inputDateFormat = "YYYY-MM-dd";
        // chart.zoomOutButton.disabled = true;

        // let dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        // dateAxis.renderer.grid.template.strokeOpacity = 0;
        // dateAxis.renderer.minGridDistance = 10;
        // dateAxis.dateFormats.setKey("day", "d");
        // dateAxis.tooltip.hiddenState.properties.opacity = 1;
        // dateAxis.tooltip.hiddenState.properties.visible = true;


        // dateAxis.tooltip.adapter.add("x", function (x, target) {
        //     return am4core.utils.spritePointToSvg({ x: chart.plotContainer.pixelX, y: 0 }, chart.plotContainer).x + chart.plotContainer.pixelWidth / 2;
        // })

        // let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        // valueAxis.renderer.inside = true;
        // valueAxis.renderer.labels.template.fillOpacity = 0.3;
        // valueAxis.renderer.grid.template.strokeOpacity = 0;
        // valueAxis.min = 0;
        // valueAxis.cursorTooltipEnabled = false;

        let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
        categoryAxis.dataFields.category = "assignmentGroup";
        categoryAxis.renderer.grid.template.location = 0;
        categoryAxis.renderer.minGridDistance = 30;
        categoryAxis.renderer.grid.template.disabled = true;

        categoryAxis.renderer.labels.template.rotation = 45;
        categoryAxis.renderer.labels.template.horizontalCenter = "left";
        // categoryAxis.renderer.labels.template.fontSize = 15;


        // // Moves Category labels next to each other on separate lines to keep from
        // //  writing atop each other
        // categoryAxis.renderer.labels.template.adapter.add("dy", function (dy, target) {
        //     if (target.dataItem && target.dataItem.index & 2 == 2) {
        //         return dy + 25;
        //     }
        //     return dy;
        // });

        let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        valueAxis.renderer.grid.template.disabled = true;
        valueAxis.fontSize = 20;

        // Create series
        let series = chart.series.push(new am4charts.ColumnSeries());
        series.dataFields.valueY = "assignmentGroupCount";
        series.dataFields.categoryX = "assignmentGroup";
        series.name = "AssignmentGroupCount"; //Visits
        series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
        series.columns.template.fillOpacity = 1;
        series.columns.template.fill = am4core.color("#1d8cc3");

        let columnTemplate = series.columns.template;
        columnTemplate.strokeWidth = 2;
        columnTemplate.strokeOpacity = 1;

        // let columnTemplate = series.columns.template;
        columnTemplate.width = 10;
        columnTemplate.column.cornerRadiusTopLeft = 20;
        columnTemplate.column.cornerRadiusTopRight = 20;
        columnTemplate.strokeOpacity = 0;

        let valueLabel = series.bullets.push(new am4charts.LabelBullet());
        valueLabel.label.text = "{assignmentGroupCount}";
        // valueLabel.label.fontSize = 20;
        valueLabel.label.truncate = false;
        valueLabel.label.hideOversized = false;
        valueLabel.label.verticalCenter = "bottom";

        chart.maskBullets = false;


        // goal guides
        // let axisRange = valueAxis.axisRanges.create();
        // axisRange.value = 6000;
        // axisRange.grid.strokeOpacity = 0.1;
        // axisRange.label.text = "Goal";
        // axisRange.label.align = "right";
        // axisRange.label.verticalCenter = "bottom";
        // axisRange.label.fillOpacity = 0.8;

        // valueAxis.renderer.gridContainer.zIndex = 1;

        // let axisRange2 = valueAxis.axisRanges.create();
        // axisRange2.value = 12000;
        // axisRange2.grid.strokeOpacity = 0.1;
        // axisRange2.label.text = "2x goal";
        // axisRange2.label.align = "right";
        // axisRange2.label.verticalCenter = "bottom";
        // axisRange2.label.fillOpacity = 0.8;

        //     let series = chart.series.push(new am4charts.ColumnSeries);
        //     series.dataFields.valueY = "steps";
        //     series.dataFields.dateX = "date";
        //     series.tooltipText = "{valueY.value}";
        //     series.tooltip.pointerOrientation = "vertical";
        //     series.tooltip.hiddenState.properties.opacity = 1;
        //     series.tooltip.hiddenState.properties.visible = true;
        //     series.tooltip.adapter.add("x", function (x, target) {
        //         return am4core.utils.spritePointToSvg({ x: chart.plotContainer.pixelX, y: 0 }, chart.plotContainer).x + chart.plotContainer.pixelWidth / 2;
        //     })


        //     columnTemplate.adapter.add("fill", function (fill, target) {
        //         let dataItem = target.dataItem;
        //         if (dataItem.valueY > 6000) {
        //             return chart.colors.getIndex(0);
        //         }
        //         else {
        //             return am4core.color("#a8b3b7");
        //         }
        //     })

        //     let cursor = new am4charts.XYCursor();
        //     cursor.behavior = "panX";
        //     chart.cursor = cursor;
        //     cursor.lineX.disabled = true;

        //     chart.events.on("datavalidated", function () {
        //         dateAxis.zoomToDates(new Date(2018, 0, 21), new Date(2018, 1, 1), false, true);
        //     });

        //     let middleLine = chart.plotContainer.createChild(am4core.Line);
        //     middleLine.strokeOpacity = 1;
        //     middleLine.stroke = am4core.color("#000000");
        //     middleLine.strokeDasharray = "2,2";
        //     middleLine.align = "center";
        //     middleLine.zIndex = 1;
        //     middleLine.adapter.add("y2", function (y2, target) {
        //         return target.parent.pixelHeight;
        //     })

        //     cursor.events.on("cursorpositionchanged", updateTooltip);
        //     dateAxis.events.on("datarangechanged", updateTooltip);

        //     function updateTooltip() {
        //         dateAxis.showTooltipAtPosition(0.5);
        //         series.showTooltipAtPosition(0.5, 0);
        //         series.tooltip.validate(); // otherwise will show other columns values for a second
        //     }


        //     let label = chart.plotContainer.createChild(am4core.Label);
        //     label.text = "Pan chart to change date";
        //     label.x = 90;
        //     label.y = 50;

        return chart.baseId;
    }



}
