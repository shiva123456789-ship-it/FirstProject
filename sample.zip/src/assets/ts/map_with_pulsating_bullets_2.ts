/* Imports */
import * as am4core from "@amcharts/amcharts4/core";
import * as am4maps from "@amcharts/amcharts4/maps";
import am4geodata_continentsLow from "@amcharts/amcharts4-geodata/continentsLow";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";




interface Inc_Details {
  incidentNumber: string;
  priority: string;
  state: string;
  regionsImpacted: string;
  shortDescription: string;
}
interface Region_Cordinates {
  "lats": number;
  "longs": number;

}
export class MapWithPulsatingBullets_2 {

  regions_in_na_cordinates: Region_Cordinates[];
  regions_in_sa_cordinates: Region_Cordinates[];
  regions_in_apac_cordinates: Region_Cordinates[];
  regions_in_eu_cordinates: Region_Cordinates[];
  regions_in_global_cordinates: Region_Cordinates[];
  current_continent_cordinates: Region_Cordinates[];
  continent_and_coordinates: { [continent: string]: { region_and_coordinates: Region_Cordinates[] } } = {};

  constructor() {

  }
  
  
  
  loadIncidentsByRegion_2(includeRegion: any, incidentsDetails: Inc_Details[], bulletPointSize: number) {

    /* Chart code */

    // add license to remove amCharts branding
    am4core.addLicense("MP259524912");

    // Themes begin
    am4core.useTheme(am4themes_animated);
    // Themes end

    // Create map instance
    let chart_div_id = "incidents_by_region_" + includeRegion;
    let chart = am4core.create(chart_div_id, am4maps.MapChart);

    // Set map definition
    chart.geodata = am4geodata_continentsLow;

    // Set projection
    chart.projection = new am4maps.projections.Miller();
    //chart.projection = new am4maps.projections.NaturalEarth1();


    // Create map polygon series
    let polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());

    // Conntinents to include
    if (includeRegion == "global") {

      // Exclude Antartica
      polygonSeries.exclude = ["antarctica"];

    }
    else if (includeRegion == "apac") {
      polygonSeries.include = ["asia", "oceania"];
      // Center on Pacic
      chart.deltaLongitude = -154.8;
      chart.homeZoomLevel = 2;
      chart.homeGeoPoint = {
        latitude: 40,
        longitude: 110
      };


    }
    else {
      polygonSeries.include = [includeRegion];

    }

    // Make map load polygon (like country names) data from GeoJSON
    polygonSeries.useGeodata = true;

    // Configure series
    let polygonTemplate = polygonSeries.mapPolygons.template;
    polygonTemplate.tooltipText = "{name}";

    // let something = "This box has a height and a width. This means that if there is too"
    //      + "much content to be displayed within the assigned height, there will be an overflow situation." + 
    //      " If overflow is set to hidden then any overflow will not be visible";
    // polygonTemplate.tooltipText = something;

    polygonTemplate.polygon.fillOpacity = 0.6;

    let gradient = new am4core.LinearGradient();
    gradient.addColor(am4core.color("#A3CC39")); //#
    gradient.addColor(am4core.color("#5CBC43")); //76ad00
    gradient.addColor(am4core.color("#228b22")); //00ad68
    polygonTemplate.fill = gradient;//am4core.color("#00AD50");


    // Create hover state and set alternative fill color
    let hs = polygonTemplate.states.create("hover");
    hs.properties.fill = chart.colors.getIndex(0);

    // Add image series
    let imageSeries = chart.series.push(new am4maps.MapImageSeries());
    imageSeries.mapImages.template.propertyFields.longitude = "longitude";
    imageSeries.mapImages.template.propertyFields.latitude = "latitude";
    imageSeries.mapImages.template.propertyFields.url = "url";


    // imageSeries.mapImages.template.tooltipText = "{title}";

    //configure tooltip here
    let tooltip = imageSeries.tooltip;
    tooltip.getFillFromObject = false;
    // tooltip.label.propertyFields.fill = "#808080";//"color";
    // tooltip.background.propertyFields.stroke = "#808080";//"color";
    // tooltip.background.fill = am4core.color("#67b7dc");
    tooltip.background.fill = am4core.color("#434343");
    // tooltip.background.stroke = am4core.color("#434343");
    tooltip.background.strokeWidth = 0;
    tooltip.background.opacity = .9;//.5;
    // tooltip.paddingLeft = 0;
    // tooltip.paddingRight = 0;
    tooltip.label.padding(0,0,0,0);
    

    // tooltip.label.wrap = true;
    tooltip.label.interactionsEnabled = true;
    // tooltip.label.paddingRight = 10;
    tooltip.label.wrap = true;
    tooltip.keepTargetHover = true;

    // tooltip.maxWidth = 50;
    tooltip.maxHeight = 75;
    // tooltip.width = 450;
    // tooltip.height = 350;


    let incidentTitle = "{title}";
    let incidentState = "{state}"
    let incidentDescription = "{description}";
    // let incidentDescription = "test";
    // let incidentDescription = "This is a long test to test out the max height that can be put in the container This is a long test ot test out the max width that can be put in the container";
    let htmlText = '<div class="toolTipBullets"> <div id="toolTipTitle"><strong> ' + incidentTitle + '| ' + incidentState + '</strong></div> <div id="toolTipDescription">' +
     incidentDescription + '</div> </div>';

    imageSeries.mapImages.template.tooltipHTML = htmlText;


    let circle = imageSeries.mapImages.template.createChild(am4core.Circle);
    //Set the size of the bulletpoint of the map based on bulletPointSize parameter
    // if(bulletPointSize == 1)
    //   circle.radius = .5;
    //   else circle.radius = 1;

    circle.radius = bulletPointSize;

    circle.propertyFields.fill = "color";

    let circle2 = imageSeries.mapImages.template.createChild(am4core.Circle);
    
    // if(bulletPointSize == 1)
    //   circle2.radius = .5;
    //   else circle2.radius = 1;

    circle2.radius = bulletPointSize;

    circle2.propertyFields.fill = "color";


    circle2.events.on("inited", function (ready) {
      animateBullet(ready.target);
    })


    function animateBullet(circle) {
      let animation = circle.animate([{ property: "scale", from: 1, to: 5 },
      { property: "opacity", from: 1, to: 0 }], 1000, am4core.ease.circleOut);
      animation.events.on("animationended", function (event) {
        animateBullet(event.target.object);
      })
    }

    let colorSet = new am4core.ColorSet();


    imageSeries.data = this.getImageSerieData(includeRegion, incidentsDetails);


    // let legend = chart.legend = new am4maps.Legend();
    // // legend.position = "right";
    // legend.valign = "top";
    // legend.maxWidth = 300;
    // legend.maxHeight = 20;

    // legend.useDefaultMarker = true;
    // let marker:any = legend.markers.template.children.getIndex(0);
    // // legend.markers.template.children.
    // marker.width = 15;
    // marker.height = 15;
    // marker.cornerRadius(12, 12, 12, 12);
    // marker.strokeWidth = 4;

    return chart.baseId;


  }

  //{ "lats": 40.7128, "longs": -74.006 }
  //{ "lats": 34.0522, "longs": -118.2437 }
  //{ "lats": 37.7749, "longs": -122.4194 }
  //{ "lats": 41.8781, "longs": -87.6298 }
  //{ "lats": 42.3601, "longs": -71.0589 }
  //{ "lats": 36.1699, "longs": -115.1398 }
  //{ "lats": 38.9072, "longs": -77.0369 }


  getImageSerieData(includeRegion: any, incidentsDetails: Inc_Details[]) {
    this.regions_in_na_cordinates = [{ "lats": 35.89, "longs": -105.85},
    { "lats": 55.94, "longs": -110.30 }, { "lats": 41.69, "longs": -87.85 }, { "lats": 50.93, "longs": -115.38 },
    { "lats": 45.2, "longs": -100.76 }, { "lats": 35.31, "longs": -84.244 }, { "lats": 42.19, "longs": -111.43 }];

    // this.regions_in_sa_cordinates = [{ "lats": -22.9068, "longs": -43.1729 },
    // { "lats": -33.4489, "longs": -70.6693 }, { "lats": -23.5505, "longs": -46.6333 }, { "lats": -14.235, "longs": -51.9253 },
    // { "lats": -0.1807, "longs": -78.4678 }, { "lats": -12.0464, "longs": -77.0428 }, { "lats": 4.711, "longs": -74.0721 }];

    this.regions_in_sa_cordinates = [{ "lats": -3.13, "longs": -65.39 },
    { "lats": -17.16, "longs": -55.79 }, { "lats": -30.10, "longs": -58.59 }, { "lats": -40.03, "longs": -69.27 },
    { "lats": -24.79, "longs": -65.46 }, { "lats": -21.64, "longs": -50.04 }, { "lats": -13.26, "longs": -47.37 }];

    // this.regions_in_apac_cordinates = [{ "lats": 28.7041, "longs": 77.1025 },
    // { "lats": 22.3193, "longs": 114.1694 }, { "lats": 39.9042, "longs": 116.4074 }, { "lats": 3.139, "longs": 101.6869 },
    // { "lats": 41.0082, "longs": 28.9784 }, { "lats": 25.2048, "longs": 55.2708 }, { "lats": 1.3521, "longs": 103.8198 }];

    this.regions_in_apac_cordinates = [{ "lats": 41.58, "longs": 93.68 },
    { "lats": 49.23, "longs": 100.71 }, { "lats": 28.54, "longs": 78.38 }, { "lats": 60.93, "longs": 85.72 },
    { "lats": 45.09, "longs": 76.96 }, { "lats": 25.2048, "longs": 44.2708 }, { "lats": 55.39, "longs": 111.82 }];

    // this.regions_in_eu_cordinates = [{ "lats": 40.4637, "longs": -3.7492 },
    // { "lats": 53.1424, "longs": -7.6921 }, { "lats": 48.8566, "longs": 2.3522 }, { "lats": 41.9028, "longs": 12.4964 },
    // { "lats": 51.5074, "longs": -0.1278 }, { "lats": 52.3676, "longs": 4.9041 }, { "lats": 45.4408, "longs": 12.3155 }];

    this.regions_in_eu_cordinates = [{ "lats": 50.67, "longs": 30.06 },
    { "lats": 57.54, "longs": 45.50 }, { "lats": 45.04, "longs": 23.44 }, { "lats": 60.96, "longs": 37.23 },
    { "lats": 52.03, "longs": 39.26 }, { "lats": 63.22, "longs": 50.30 }, { "lats": 39.52, "longs": 36.63 }];

    this.regions_in_global_cordinates = this.regions_in_na_cordinates;

    this.continent_and_coordinates['northAmerica'] = { region_and_coordinates: this.regions_in_na_cordinates };
    this.continent_and_coordinates['southAmerica'] = { region_and_coordinates: this.regions_in_sa_cordinates };
    this.continent_and_coordinates['apac'] = { region_and_coordinates: this.regions_in_apac_cordinates };
    this.continent_and_coordinates['europe'] = { region_and_coordinates: this.regions_in_eu_cordinates };
    this.continent_and_coordinates['global'] = { region_and_coordinates: this.regions_in_na_cordinates };



    am4core.addLicense("CH213722778");
    let colorSet = new am4core.ColorSet();
    let p1_incident_color = am4core.color("#ff0404"); //
    let p2_incident_color = am4core.color("#ffc404"); //

    let imageSeries_data: {
      "title": string, "state": string, "description": string, "latitude": number, "longitude": number,
      "color": am4core.Color
    }[] = [];

    let inc_n: number = 0;
    this.current_continent_cordinates = this.continent_and_coordinates[includeRegion].region_and_coordinates;

    let region_and_coordinates: { [continent: string]: { message: Region_Cordinates[] } } = {};

    console.log(`For Region: ${includeRegion}`);
    console.log(`All incidentsDetails: ${incidentsDetails}`);

    for (let incident of incidentsDetails) {
      let incident_bullet_color = am4core.color();

      if (incident.priority === "1 - Critical") {
        incident_bullet_color = p1_incident_color;
      } else {
        incident_bullet_color = p2_incident_color;

      }
      try{
        imageSeries_data.push({
          "title": incident.incidentNumber,
          "state": incident.state,
          "description": incident.shortDescription,
          "latitude": this.current_continent_cordinates[inc_n].lats,
          "longitude": this.current_continent_cordinates[inc_n].longs,
          "color": incident_bullet_color //colorSet.next()
        });
      }catch (error) {
        console.log("Warning: Incidents more than co-ordinates");
      }


      inc_n++;
    }


    return imageSeries_data;

  }
}