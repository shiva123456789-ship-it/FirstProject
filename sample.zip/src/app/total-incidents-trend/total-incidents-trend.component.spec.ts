import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalIncidentsTrendComponent } from './total-incidents-trend.component';

describe('TotalIncidentsTrendComponent', () => {
  let component: TotalIncidentsTrendComponent;
  let fixture: ComponentFixture<TotalIncidentsTrendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotalIncidentsTrendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TotalIncidentsTrendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
