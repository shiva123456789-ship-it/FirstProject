import { Component, Input, OnInit } from '@angular/core';

interface Outage_Details {
  incidentNumber : string;
  priority : string;
  state : string;
  regionsImpacted:string; 
  shortDescription: string;
}

@Component({
  selector: 'app-outage-details',
  templateUrl: './outage-details.component.html',
  styleUrls: ['./outage-details.component.css']
})
export class OutageDetailsComponent implements OnInit {

  @Input() outageDetails : Outage_Details;
  @Input() outage_number : number;

  settings_imagePath : string;
  settings_imagePaths : string[];
  service_images: string[];
  constructor() { }

  ngOnInit(): void {
    this.settings_imagePath ='../../../assets/images/settings_1_45x45.jpg';
    this.settings_imagePaths = ["../../../assets/images/settings_1_45x45.jpg",
    "../../../assets/images/service2_1_45x45.jpg",
    "na","na","na","../../../assets/images/settings_1_45x45.jpg",
    "../../../assets/images/service2_1_45x45.jpg",
    "na","na","na"
  ];
  this.service_images = ["service1_1_45x45.jpg","service2_1_45x45.jpg","service3_1_45x45.jpg",
  "service4_1_45x45.jpg","service5_1_45x45.jpg","service1_1_45x45.jpg","service2_1_45x45.jpg","service3_1_45x45.jpg",
  "service4_1_45x45.jpg","service5_1_45x45.jpg"
];
  this.settings_imagePath = "../../../assets/images/" + this.service_images[this.outage_number];
  }

}
